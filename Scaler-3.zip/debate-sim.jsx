/* Debate simulation engine — scripted multi-agent debate with P&L ticks */

const DEBATE_SCRIPT = [
  { at: 2, speaker: 'USA', stance: 'support', text: 'We propose coordinated humanitarian relief operations through established NATO logistics channels. The United States is prepared to commit carrier group assets for rapid deployment to affected coastal zones.', pnl: { USA: -0.02, IND: 0.015 } },
  { at: 5, speaker: 'CHN', stance: 'modify', text: 'This aid must not be tied to political conditions or military presence. China supports humanitarian assistance through UN mechanisms only — not bilateral arrangements that create dependency. We will contribute through the Asian Infrastructure Investment Bank.', pnl: { CHN: -0.01, IND: 0.01 } },
  { at: 8, speaker: 'RUS', stance: 'oppose', text: 'We note with concern the militarization of humanitarian corridors. Russia cannot support operations that position NATO naval assets in the Indian Ocean under humanitarian pretexts. Our counter-proposal routes aid through BRICS channels.', pnl: { RUS: 0.005 } },
  { at: 11, speaker: 'IND', stance: 'modify', text: 'India exercises strategic autonomy in accepting bilateral aid. We welcome assistance from all partners but insist on sovereign control of distribution. The disaster zone falls within our exclusive economic zone and territorial waters.', pnl: { IND: 0.02 } },
  { at: 14, speaker: 'DPRK', stance: 'oppose', text: 'The imperialist powers use disasters to extend military reach. We reject any framework that normalizes foreign naval presence near sovereign waters. The DPRK stands with non-aligned nations.', pnl: { DPRK: -0.005 } },
  { at: 17, speaker: 'SAU', stance: 'support', text: 'The Kingdom is prepared to fund reconstruction through a $2 billion sovereign wealth commitment, contingent on energy infrastructure receiving priority in rebuilding efforts. We propose a joint energy-humanitarian framework.', pnl: { SAU: -0.015, IND: 0.025 } },
  { at: 20, speaker: 'UNESCO', stance: 'mediate', text: 'Three World Heritage sites in the affected zone face irreversible damage. Under Article 1.2 of the Convention, I urge all parties to establish a 48-hour cultural protection corridor before military logistics begin. The Sundarbans mangrove system and two archaeological sites require immediate safeguarding.', pnl: {} },
  { at: 25, speaker: 'USA', stance: 'oppose', text: 'We cannot delay relief operations for 48 hours while people are at immediate risk. Heritage protection is important but secondary to saving lives. We propose parallel tracks — relief deployment begins immediately with heritage zones marked as no-go sectors.', pnl: { USA: -0.01 } },
  { at: 28, speaker: 'RUS', stance: 'oppose', text: 'The American proposal for parallel tracks is a transparent attempt to establish facts on the ground. If NATO ships enter the Indian Ocean, Russia will deploy observer vessels to ensure compliance with international maritime law.', pnl: { RUS: -0.02 } },
  { at: 31, speaker: 'CHN', stance: 'oppose', text: 'We firmly oppose any military escalation in the guise of humanitarian operations. China calls for an emergency session of the UN Security Council before any deployment proceeds. Unilateral action undermines the multilateral order.', pnl: { CHN: -0.005 } },
  { at: 34, speaker: 'IND', stance: 'support', text: 'India will accept the parallel-track proposal on the condition that all foreign military assets operate under Indian naval command within our exclusive economic zone. This is non-negotiable and consistent with our sovereignty.', pnl: { IND: 0.03 } },
  { at: 37, speaker: 'SAU', stance: 'modify', text: 'The Kingdom proposes a compromise: civilian-flagged relief vessels only, funded through the joint Saudi-Indian energy corridor, with military standoff distance of 200 nautical miles. This preserves sovereignty while enabling rapid response.', pnl: { SAU: -0.01, IND: 0.015 } },
  { at: 40, speaker: 'UNESCO', stance: 'mediate', text: 'I note the emerging consensus around civilian-only operations. The Sundarbans buffer zone must be designated regardless of the military question. I am invoking the Rapid Response Mechanism under the 2003 Convention for Intangible Cultural Heritage — fishing communities in Zone 3 face permanent displacement.', pnl: {} },
  { at: 44, speaker: 'DPRK', stance: 'oppose', text: 'Empty words. The so-called international community has never protected the sovereignty of smaller nations. We will not participate in any vote that legitimizes foreign intervention under any flag.', pnl: { DPRK: -0.01 } },
];

const COMPANY_UPDATES = [
  { at: 5, updates: { AAPL: { price: 189.32, pct: 0.8 }, BYDDY: { price: 215.40, pct: -0.6 } } },
  { at: 12, updates: { GAZP: { price: 139.20, pct: -3.8 }, RELI: { price: 2860.00, pct: 0.9 } } },
  { at: 20, updates: { AAPL: { price: 187.10, pct: -0.4 }, '2222': { price: 33.10, pct: 2.2 } } },
  { at: 30, updates: { GAZP: { price: 136.00, pct: -5.1 }, BYDDY: { price: 218.20, pct: 0.7 }, KOMID: { price: 86.50, pct: -2.2 } } },
  { at: 40, updates: { RELI: { price: 2890.00, pct: 1.9 }, '2222': { price: 33.80, pct: 3.5 }, AAPL: { price: 190.50, pct: 1.4 } } },
];

function useDebateSimulation() {
  const [state, setState] = React.useState({
    running: false, step: 0, maxSteps: 50,
    utterances: [], activeSpeakerId: null,
    pnlRows: AGENTS.map(a => ({
      countryId: a.id, countryName: a.name, tint: a.tint,
      metrics: { gdp: 0, jobs: 0, energy: 0, influence: 0, welfare: 0, heritage: 0, military: 0 },
      deltasSinceLastTick: {},
    })),
    companyTicks: COMPANIES.map(c => ({ ...c })),
    voteTally: null,
    rhetoricAlert: null,
    unescoUtterance: null,
    heritageAtRisk: [
      { siteName: 'Sundarbans Mangrove', countryId: 'IND', riskScore: 0.82 },
      { siteName: 'Mahabodhi Temple', countryId: 'IND', riskScore: 0.45 },
      { siteName: 'Kaziranga National Park', countryId: 'IND', riskScore: 0.31 },
    ],
    involvement: { involved: ['USA', 'IND', 'SAU'], peripheral: ['CHN', 'RUS', 'UNESCO'], uninvolved: ['DPRK'] },
  });

  const stateRef = React.useRef(state);
  stateRef.current = state;
  const timerRef = React.useRef(null);

  const tick = React.useCallback(() => {
    setState(prev => {
      if (!prev.running || prev.step >= prev.maxSteps) return { ...prev, running: false };
      const next = { ...prev, step: prev.step + 1, activeSpeakerId: null };

      // Apply debate script
      DEBATE_SCRIPT.forEach(evt => {
        if (evt.at === next.step) {
          const agent = AGENTS.find(a => a.id === evt.speaker);
          next.utterances = [...next.utterances, {
            step: next.step, speakerId: evt.speaker,
            speakerName: agent?.name || evt.speaker,
            speakerTint: agent?.tint || '#fff',
            text: evt.text, stance: evt.stance,
            pnlDeltas: evt.pnl || {},
            timestamp: Date.now(),
          }];
          next.activeSpeakerId = evt.speaker;

          // Update P&L
          if (evt.pnl) {
            next.pnlRows = next.pnlRows.map(row => {
              const delta = evt.pnl[row.countryId] || 0;
              if (delta === 0) return { ...row, deltasSinceLastTick: {} };
              return {
                ...row,
                metrics: { ...row.metrics, gdp: row.metrics.gdp + delta, welfare: row.metrics.welfare + delta * 0.5, influence: row.metrics.influence + delta * 0.3 },
                deltasSinceLastTick: { gdp: delta, welfare: delta * 0.5, influence: delta * 0.3 },
              };
            });
          }

          // UNESCO card
          if (evt.speaker === 'UNESCO') {
            next.unescoUtterance = next.utterances[next.utterances.length - 1];
          }
        }
      });

      // Company updates
      COMPANY_UPDATES.forEach(evt => {
        if (evt.at === next.step) {
          next.companyTicks = next.companyTicks.map(c => {
            const upd = evt.updates[c.symbol];
            return upd ? { ...c, price: upd.price, pct: upd.pct } : c;
          });
        }
      });

      // Rhetoric cold war alert at step 31 (USA vs RUS consecutive opposes)
      if (next.step === 31) {
        next.rhetoricAlert = { agents: ['USA', 'Russia'], count: 4, topic: 'energy-sanction retaliation', index: 0.87 };
      }

      // Involvement update after step 14
      if (next.step === 14) {
        next.involvement = { involved: ['USA', 'IND', 'CHN', 'SAU'], peripheral: ['RUS', 'UNESCO'], uninvolved: ['DPRK'] };
      }

      // Vote at step 44
      if (next.step === 45) {
        next.voteTally = { support: 3, oppose: 2, modify: 1 };
      }

      return next;
    });
  }, []);

  const start = React.useCallback(() => setState(p => ({ ...p, running: true })), []);
  const pause = React.useCallback(() => setState(p => ({ ...p, running: false })), []);
  const reset = React.useCallback(() => setState({
    running: false, step: 0, maxSteps: 50,
    utterances: [], activeSpeakerId: null,
    pnlRows: AGENTS.map(a => ({
      countryId: a.id, countryName: a.name, tint: a.tint,
      metrics: { gdp: 0, jobs: 0, energy: 0, influence: 0, welfare: 0, heritage: 0, military: 0 },
      deltasSinceLastTick: {},
    })),
    companyTicks: COMPANIES.map(c => ({ ...c })),
    voteTally: null, rhetoricAlert: null, unescoUtterance: null,
    heritageAtRisk: [
      { siteName: 'Sundarbans Mangrove', countryId: 'IND', riskScore: 0.82 },
      { siteName: 'Mahabodhi Temple', countryId: 'IND', riskScore: 0.45 },
      { siteName: 'Kaziranga National Park', countryId: 'IND', riskScore: 0.31 },
    ],
    involvement: { involved: ['USA', 'IND', 'SAU'], peripheral: ['CHN', 'RUS', 'UNESCO'], uninvolved: ['DPRK'] },
  }), []);

  React.useEffect(() => {
    if (state.running) timerRef.current = setInterval(tick, 800);
    else clearInterval(timerRef.current);
    return () => clearInterval(timerRef.current);
  }, [state.running, tick]);

  return { state, start, pause, reset };
}

Object.assign(window, { useDebateSimulation, DEBATE_SCRIPT });
